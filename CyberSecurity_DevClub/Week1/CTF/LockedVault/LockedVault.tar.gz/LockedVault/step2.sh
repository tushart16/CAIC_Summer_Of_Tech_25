#!/bin/bash
if [ "$EUID" -eq 0 ]; then
    echo "ERROR: Don't run this as root/sudo!"
    echo "Run as: bash $0"
    exit 1
fi
echo "Enter the password from step1:"
read -r input
if [ "$(printf $input | base64)" = "dW5sb2NrMTIz" ]; then
    echo "Correct! Moving to final step..."
    key="ZmluYWxfa2V5XzQ1Ng=="
    echo "Key for step3: $(echo $key | base64 -d)"
else
    echo "Wrong password! Go back to step1."
    exit 1
fi
