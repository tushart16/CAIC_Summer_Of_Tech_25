#!/bin/bash
# First step - decode the password
if [ "$EUID" -eq 0 ]; then
    echo "ERROR: Don't run this as root/sudo!"
    echo "Run as: bash $0"
    exit 1
fi
password="dW5sb2NrMTIz"
echo "Step 1 complete!"
echo "Password found: $(echo $password | base64 -d)"
echo "Now make step2.sh executable and run it with this password!"
