LOCKED VAULT CHALLENGE

You have 3 scripts but they have restrictive permissions:
- step1.sh: Cannot be read (need to fix permissions to see the password)
- step2.sh: Cannot be executed (need to make executable and use password from step1)  
- step3.sh: Cannot be read (need to fix permissions and use key from step2)

Each script checks for the correct input from the previous step.
Even if you bypass permissions with sudo, you still need to solve each step properly!

Start by fixing permissions on step1.sh and reading it.
