#!/bin/bash
if [ "$EUID" -eq 0 ]; then
    echo "ERROR: Don't run this as root/sudo!"
    echo "Run as: bash $0"
    exit 1
fi
echo "Enter the key from step2:"
read -r input
if [ "$(printf $input | base64)" = "ZmluYWxfa2V5XzQ1Ng==" ]; then
    # XOR encoded flag with key
    encoded_flag="ZGNDVEZ7eTB1XzRyM180X3Azcm0xc3MxMG5faDBja2NyX24wd30="
    echo "Vault unlocked!"
    echo "Flag: $(echo $encoded_flag | base64 -d)"
else
    echo "Wrong key! Complete the previous steps first."
    exit 1
fi
